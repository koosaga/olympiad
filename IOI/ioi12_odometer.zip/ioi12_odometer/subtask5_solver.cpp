#include <bits/stdc++.h>
using namespace std;
using lint = long long;
using pi = pair<lint, lint>;
#define sz(v) ((int)(v).size())
#define all(v) (v).begin(), (v).end()

int main(){	
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cout << "right" << endl;
	cout << "jump L0" << endl;
	for(int i = 0; i <= 14; i++){
		cout << "G" << i << ":" << endl;
		cout << "right" << endl;
		if(i + 1 <= 14) cout << "border L" << i+1 << endl;
		else cout << "border done0" << endl;
		cout << "move" << endl;
		cout << "right" << endl;

		cout << "H" << i << ":" << endl;
		cout << "move" << endl;
		cout << "border I" << i << endl;
		cout << "jump H" << i << endl;

		cout << "I" << i << ":" << endl;
		cout << "right" << endl;

		cout << "right" << endl;
		cout << "L" << i << ":" << endl;
		for(int j = 0; j < i; j++) cout << "get" << endl;
		cout << "pebble M" << i << endl; 
		cout << "jump done" << i << endl;

		cout << "M" << i << ":" << endl;
		for(int j = 0; j < i; j++) cout << "put" << endl;
		cout << "border G" << i << endl;
		cout << "move" << endl;
		cout << "jump L" << i << endl;
	}
	for(int i = 14; i >= 0; i--){
		cout << "done" << i << ":" << endl;
		if(i) cout << "put" << endl;
	}
}


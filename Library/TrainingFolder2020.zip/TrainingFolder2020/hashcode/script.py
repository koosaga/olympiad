import os

while True:
	os.system("./e_withrand <e_so_many_books.txt ")

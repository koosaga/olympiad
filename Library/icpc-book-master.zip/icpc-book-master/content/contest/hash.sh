tr -d '[:space:]' | md5sum
